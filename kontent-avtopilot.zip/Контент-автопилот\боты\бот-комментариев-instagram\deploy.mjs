import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = dirname(fileURLToPath(import.meta.url));
const rd = (p) => readFileSync(join(dir, p), 'utf8').trim();

const account = rd('cf-account.txt');
const cfToken = rd('cf-token.txt');
const igToken = rd(join('..', 'Threads-система', 'autoposter', 'ig-token.txt'));
const keywords = readFileSync(join(dir, 'keywords.json'), 'utf8');
const workerCode = readFileSync(join(dir, 'worker.js'), 'utf8');
const scriptName = 'ig-bot';
const verifyToken = 'ТВОЙ-VERIFY-TOKEN';
const igUserId = 'ТВОЙ_IG_USER_ID';

const metadata = {
  main_module: 'worker.js',
  compatibility_date: '2024-11-01',
  bindings: [
    { type: 'secret_text', name: 'IG_TOKEN', text: igToken },
    { type: 'plain_text', name: 'VERIFY_TOKEN', text: verifyToken },
    { type: 'plain_text', name: 'IG_USER_ID', text: igUserId },
    { type: 'plain_text', name: 'KEYWORDS_JSON', text: keywords },
    { type: 'kv_namespace', name: 'DEBUG', namespace_id: 'ТВОЙ_KV_NAMESPACE_ID' },
  ],
};

const fd = new FormData();
fd.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
fd.append('worker.js', new Blob([workerCode], { type: 'application/javascript+module' }), 'worker.js');

const put = await fetch(
  `https://api.cloudflare.com/client/v4/accounts/${account}/workers/scripts/${scriptName}`,
  { method: 'PUT', headers: { Authorization: `Bearer ${cfToken}` }, body: fd }
);
const putJson = await put.json();
if (!putJson.success) {
  console.log('UPLOAD FAILED:', JSON.stringify(putJson.errors, null, 2));
  process.exit(1);
}
console.log('Worker uploaded OK');

// включить публичный workers.dev URL
const sd = await fetch(
  `https://api.cloudflare.com/client/v4/accounts/${account}/workers/scripts/${scriptName}/subdomain`,
  { method: 'POST', headers: { Authorization: `Bearer ${cfToken}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled: true }) }
);
console.log('subdomain enable:', sd.status);

// узнать поддомен аккаунта
const subRes = await fetch(
  `https://api.cloudflare.com/client/v4/accounts/${account}/workers/subdomain`,
  { headers: { Authorization: `Bearer ${cfToken}` } }
);
const subJson = await subRes.json();
const sub = subJson.result?.subdomain;
console.log('');
console.log('===== ГОТОВО =====');
console.log('URL вебхука:  https://' + scriptName + '.' + sub + '.workers.dev');
console.log('Verify token: ' + verifyToken);
