# Рисует карусели: твоё фото (затемнённое) + крупный текст + слайд с ключевым словом.
# Запуск: python make_carousels.py     (нужен установленный Google Chrome)
import os, glob, random, subprocess, json, urllib.parse, shutil
from content import CAROUSELS, HANDLE, GITHUB_PAGES_URL

BASE = os.path.dirname(os.path.abspath(__file__))
PHOTOS = os.path.join(BASE, "фото")
OUT = os.path.join(BASE, "готово")
WORK = os.path.join(BASE, "work"); os.makedirs(WORK, exist_ok=True); os.makedirs(OUT, exist_ok=True)

# Chrome и ffmpeg — Claude подставит правильные пути при настройке
CHROME = os.environ.get("CHROME_PATH", r"C:\Program Files\Google\Chrome\Application\chrome.exe")
FF = os.environ.get("FFMPEG_PATH", "ffmpeg")
FONT_BLACK = os.path.join(BASE, "шрифты", "Montserrat-Black.ttf")
FONT_BOLD = os.path.join(BASE, "шрифты", "Montserrat-Bold.ttf")

furl = lambda p: "file:///" + urllib.parse.quote(p.replace("\\", "/"), safe="/:")
W, H = 1080, 1440

# фото: убираем дубли, перемешиваем
seen, files = set(), []
for f in sorted(glob.glob(os.path.join(PHOTOS, "*.*"))):
    if not f.lower().endswith((".jpg", ".jpeg", ".png")): continue
    sz = os.path.getsize(f)
    if sz in seen: continue
    seen.add(sz); files.append(f)
if not files:
    raise SystemExit("Положи свои фото в папку 'фото/' — без них карусели не собрать.")
random.seed(7); random.shuffle(files)
# обложки берём максимально разные — с шагом по списку
step = max(1, len(files) // max(1, len(CAROUSELS)))
covers = [files[(i * step) % len(files)] for i in range(len(CAROUSELS))]
pool = [f for f in files if f not in covers] or files

def html(slide, photo, idx, total):
    kw = ""
    if slide["t"] == "cta":
        kw = f'<div class="kw">{slide["kw"]}</div><div class="ft">{slide.get("f","")}</div>'
    num = f'<div class="num">{idx-1}</div>' if idx > 1 else ""      # обложка без номера
    hs = 92 if slide["t"] in ("hook", "cta", "s") else 84
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>
@font-face{{font-family:MB;src:url('{furl(FONT_BLACK)}')}}
@font-face{{font-family:MBd;src:url('{furl(FONT_BOLD)}')}}
*{{margin:0;padding:0;box-sizing:border-box}}
html,body{{width:{W}px;height:{H}px;overflow:hidden}}
.bg{{position:absolute;inset:0;background:url('{furl(photo)}') center/cover;filter:brightness(.4) saturate(.85)}}
.tint{{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.5),rgba(0,0,0,.5) 45%,rgba(0,0,0,.88))}}
.g{{color:#22c55e}}
.wrap{{position:absolute;inset:0;padding:96px 84px;display:flex;flex-direction:column;justify-content:center;color:#fff}}
.num{{position:absolute;top:86px;left:84px;font-family:MB;font-size:120px;color:rgba(22,163,74,.9);line-height:.8}}
h1{{font-family:MB;font-size:{hs}px;line-height:1.04;text-shadow:0 4px 24px rgba(0,0,0,.5)}}
p{{font-family:MBd;font-size:41px;line-height:1.4;color:rgba(255,255,255,.92);margin-top:34px;max-width:820px}}
.kw{{display:inline-block;background:#16a34a;color:#fff;font-family:MB;font-size:64px;padding:14px 40px;border-radius:20px;margin-top:26px}}
.ft{{font-family:MBd;font-size:38px;line-height:1.35;color:rgba(255,255,255,.9);margin-top:28px;max-width:820px}}
.h{{position:absolute;bottom:70px;left:84px;font-family:MBd;font-size:32px;color:rgba(255,255,255,.75)}}
.s{{position:absolute;bottom:70px;right:84px;font-family:MBd;font-size:32px;color:rgba(34,197,94,.95)}}
</style></head><body>
<div class="bg"></div><div class="tint"></div>{num}
<div class="wrap"><h1>{slide['h']}</h1><p>{slide['b']}</p>{kw}</div>
<div class="h">{HANDLE}</div>{'<div class="s">листай →</div>' if idx < total else ''}
</body></html>"""

queue = []
for ci, car in enumerate(CAROUSELS):
    name = car["name"]
    d = os.path.join(OUT, name); os.makedirs(d, exist_ok=True)
    for old in glob.glob(os.path.join(d, "*.jpg")): os.remove(old)
    total = len(car["slides"])
    pics = [covers[ci]] + [pool[(ci * (total - 1) + k) % len(pool)] for k in range(total - 1)]
    for i, slide in enumerate(car["slides"], 1):
        hp = os.path.join(WORK, "s.html")
        open(hp, "w", encoding="utf-8").write(html(slide, pics[i-1], i, total))
        png = os.path.join(d, f"{i:02d}.png")
        subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
                        "--force-device-scale-factor=1",
                        f"--user-data-dir={os.path.join(WORK,'chrome')}",
                        f"--screenshot={png}", f"--window-size={W},{H}", furl(hp)],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        jpg = os.path.join(d, f"{i:02d}.jpg")
        subprocess.run([FF, "-y", "-hide_banner", "-loglevel", "error", "-i", png, "-q:v", "2", jpg])
        if os.path.exists(png): os.remove(png)
    queue.append({"id": name, "caption": car["cap"],
                  "images": [f"{GITHUB_PAGES_URL}/{name}/{i:02d}.jpg" for i in range(1, total + 1)]})
    print(f"{name} готова")

json.dump(queue, open(os.path.join(BASE, "ig_queue.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"\nГотово: {len(queue)} каруселей. Картинки в 'готово/', очередь в ig_queue.json")
