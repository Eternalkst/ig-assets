﻿# Автопостер каруселей Instagram — публикует следующую карусель из ig-queue.json.
# Картинки: https://raw.githubusercontent.com/ТВОЙ-GITHUB-ЛОГИН/ig-assets/main/{id}-{n}.png
# Запуск: powershell -NoProfile -ExecutionPolicy Bypass -File ig-post.ps1 [-Preview]
param(
  [switch]$Preview
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$logFile = Join-Path $dir 'log.txt'
function Log([string]$m) {
  $line = ('{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m)
  Add-Content -Path $logFile -Value $line -Encoding UTF8
  Write-Host $line
}

$base = 'https://raw.githubusercontent.com/ТВОЙ-GITHUB-ЛОГИН/ig-assets/main'

# ---------- очередь ----------
$queue = (Get-Content (Join-Path $dir 'ig-queue.json') -Raw -Encoding UTF8 | ConvertFrom-Json).carousels
$statePath = Join-Path $dir 'ig-state.json'
$done = @()
if (Test-Path $statePath) {
  $st = Get-Content $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($st.done) { $done = @($st.done) }
}

$next = $null
foreach ($q in $queue) { if ($done -notcontains $q.id) { $next = $q; break } }
if (-not $next) { Log 'IG: очередь каруселей закончилась — добавь новые в ig-queue.json'; exit 0 }

$images = 1..$next.slides | ForEach-Object { "$base/$($next.id)-$_.png" }

if ($Preview) {
  Write-Host ("=== Следующая карусель: {0} ({1} слайдов) ===" -f $next.id, $next.slides)
  $images | ForEach-Object { Write-Host $_ }
  Write-Host '--- подпись ---'
  Write-Host $next.caption
  exit 0
}

# ---------- токен ----------
$tokenPath = Join-Path $dir 'ig-token.txt'
$metaPath  = Join-Path $dir 'ig-token-meta.json'
$meta = $null
if (Test-Path $metaPath) { $meta = Get-Content $metaPath -Raw -Encoding UTF8 | ConvertFrom-Json }
if ((-not $meta) -and (Test-Path $tokenPath)) {
  $t = (Get-Content $tokenPath -Raw -Encoding UTF8).Trim()
  if ($t) { $meta = [pscustomobject]@{ token = $t; refreshed = (Get-Date).ToString('o') }; $meta | ConvertTo-Json | Set-Content -Path $metaPath -Encoding UTF8 }
}
if (((-not $meta) -or (-not $meta.token)) -and $env:IG_TOKEN) {
  $meta = [pscustomobject]@{ token = $env:IG_TOKEN; refreshed = (Get-Date).ToString('o') }
  $meta | ConvertTo-Json | Set-Content -Path $metaPath -Encoding UTF8
}
if ((-not $meta) -or (-not $meta.token)) { Log 'IG: нет токена (ig-token.txt или секрет IG_TOKEN)'; exit 1 }
$token = $meta.token

# продление (60 дней; продлеваем после 40)
if (((Get-Date) - [datetime]$meta.refreshed).TotalDays -gt 40) {
  try {
    $r = Invoke-RestMethod -Uri ("https://graph.instagram.com/refresh_access_token?grant_type=ig_refresh_token&access_token={0}" -f $token)
    $meta = [pscustomobject]@{ token = $r.access_token; refreshed = (Get-Date).ToString('o') }
    $meta | ConvertTo-Json | Set-Content -Path $metaPath -Encoding UTF8
    $token = $r.access_token
    Log 'IG: токен продлён ещё на 60 дней'
  } catch { Log ("IG: не удалось продлить токен: {0}" -f $_.Exception.Message) }
}

# ---------- публикация ----------
$me = Invoke-RestMethod -Uri ("https://graph.instagram.com/v23.0/me?fields=user_id,username&access_token={0}" -f $token)
$uid = $me.user_id
Log ("IG: публикую карусель {0} в @{1}" -f $next.id, $me.username)

function New-Container([string]$body) {
  $c = Invoke-RestMethod -Method Post -Uri ("https://graph.instagram.com/v23.0/{0}/media" -f $uid) `
        -Body $body -ContentType 'application/x-www-form-urlencoded'
  return $c.id
}
function Wait-Ready([string]$id) {
  foreach ($try in 1..12) {
    $s = Invoke-RestMethod -Uri ("https://graph.instagram.com/v23.0/{0}?fields=status_code&access_token={1}" -f $id, $token)
    if ($s.status_code -eq 'FINISHED') { return }
    if ($s.status_code -eq 'ERROR') { throw "Контейнер $id в статусе ERROR" }
    Start-Sleep -Seconds 5
  }
  throw "Контейнер $id не готов после ожидания"
}

try {
  $children = @()
  $i = 0
  foreach ($url in $images) {
    $i++
    $id = New-Container ("image_url={0}&is_carousel_item=true&access_token={1}" -f [uri]::EscapeDataString($url), $token)
    $children += $id
    Log ("IG: слайд {0}/{1} загружен" -f $i, $next.slides)
    Start-Sleep -Seconds 2
  }
  $children | ForEach-Object { Wait-Ready $_ }

  $carousel = New-Container ("media_type=CAROUSEL&children={0}&caption={1}&access_token={2}" -f ($children -join ','), [uri]::EscapeDataString($next.caption), $token)
  Wait-Ready $carousel

  $p = Invoke-RestMethod -Method Post -Uri ("https://graph.instagram.com/v23.0/{0}/media_publish" -f $uid) `
        -Body ("creation_id={0}&access_token={1}" -f $carousel, $token) -ContentType 'application/x-www-form-urlencoded'

  $done += $next.id
  [pscustomobject]@{ done = $done } | ConvertTo-Json | Set-Content -Path $statePath -Encoding UTF8
  Log ("IG: ГОТОВО — карусель {0} опубликована (media id {1}) в @{2}" -f $next.id, $p.id, $me.username)
} catch {
  Log ("IG: ОШИБКА публикации {0}: {1}" -f $next.id, $_.Exception.Message)
  exit 1
}
