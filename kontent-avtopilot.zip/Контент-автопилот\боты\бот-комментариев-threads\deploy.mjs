// Деплой Threads-бота комментариев на Cloudflare Workers.
// Читает НАСТРОЙКИ.txt, при необходимости сам создаёт KV-хранилище, заливает воркер.
// Запуск:  node deploy.mjs
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = dirname(fileURLToPath(import.meta.url));
const cfgPath = join(dir, 'НАСТРОЙКИ.txt');
if (!existsSync(cfgPath)) {
  console.error('❌ Нет файла НАСТРОЙКИ.txt — скопируй НАСТРОЙКИ-ШАБЛОН.txt в НАСТРОЙКИ.txt и заполни.');
  process.exit(1);
}

// парсим key=value
const cfg = {};
for (const line of readFileSync(cfgPath, 'utf8').split(/\r?\n/)) {
  const s = line.trim();
  if (!s || s.startsWith('#')) continue;
  const i = s.indexOf('=');
  if (i > 0) cfg[s.slice(0, i).trim()] = s.slice(i + 1).trim();
}

const need = ['THREADS_TOKEN', 'THREADS_USER_ID', 'THREADS_USERNAME', 'CF_ACCOUNT', 'CF_TOKEN'];
for (const k of need) if (!cfg[k] || cfg[k].includes('ТВОЙ') || cfg[k].includes('___')) {
  console.error(`❌ Заполни в НАСТРОЙКИ.txt: ${k}`); process.exit(1);
}

const account = cfg.CF_ACCOUNT, cfToken = cfg.CF_TOKEN;
const scriptName = 'threads-bot';
const CF = (p, opt = {}) => fetch(`https://api.cloudflare.com/client/v4/accounts/${account}${p}`,
  { ...opt, headers: { Authorization: `Bearer ${cfToken}`, ...(opt.headers || {}) } });

// 1) KV-хранилище: создаём, если ещё нет
let kvId = cfg.KV_ID;
if (!kvId) {
  const r = await (await CF('/storage/kv/namespaces', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title: 'threads-bot-kv' }),
  })).json();
  if (!r.success) { console.error('❌ Не удалось создать KV:', JSON.stringify(r.errors)); process.exit(1); }
  kvId = r.result.id;
  writeFileSync(cfgPath, readFileSync(cfgPath, 'utf8').replace(/^KV_ID=.*$/m, `KV_ID=${kvId}`));
  console.log('✅ Создано KV-хранилище:', kvId);
}

// 2) загружаем воркер с настройками (env-биндинги)
const workerCode = readFileSync(join(dir, 'worker.js'), 'utf8');
const bindings = [
  { type: 'secret_text', name: 'THREADS_TOKEN', text: cfg.THREADS_TOKEN },
  { type: 'secret_text', name: 'ANTHROPIC_API_KEY', text: cfg.ANTHROPIC_API_KEY || '' },
  { type: 'plain_text', name: 'VERIFY_TOKEN', text: cfg.VERIFY_TOKEN || 'my_threads_bot_2026' },
  { type: 'plain_text', name: 'THREADS_USER_ID', text: cfg.THREADS_USER_ID },
  { type: 'plain_text', name: 'THREADS_USERNAME', text: cfg.THREADS_USERNAME },
  { type: 'plain_text', name: 'BOT_MODE', text: cfg.BOT_MODE || 'full' },
  { type: 'plain_text', name: 'BOT_PERSONA', text: cfg.BOT_PERSONA || '' },
  { type: 'plain_text', name: 'PROMPT_URL', text: cfg.PROMPT_URL || '' },
  { type: 'plain_text', name: 'AVTOPILOT_URL', text: cfg.AVTOPILOT_URL || '' },
  { type: 'kv_namespace', name: 'KV', namespace_id: kvId },
];
const fd = new FormData();
fd.append('metadata', new Blob([JSON.stringify({ main_module: 'worker.js', compatibility_date: '2024-11-01', bindings })], { type: 'application/json' }));
fd.append('worker.js', new Blob([workerCode], { type: 'application/javascript+module' }), 'worker.js');

const put = await (await CF(`/workers/scripts/${scriptName}`, { method: 'PUT', body: fd })).json();
if (!put.success) { console.error('❌ Ошибка загрузки:', JSON.stringify(put.errors, null, 2)); process.exit(1); }
console.log('✅ Бот загружен');

// 3) включаем публичный адрес
await CF(`/workers/scripts/${scriptName}/subdomain`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled: true }) });
const sub = (await (await CF('/workers/subdomain')).json()).result?.subdomain;

console.log('\n===== ГОТОВО =====');
console.log('URL вебхука:  https://' + scriptName + '.' + sub + '.workers.dev');
console.log('Verify token: ' + (cfg.VERIFY_TOKEN || 'my_threads_bot_2026'));
console.log('\nДальше — подключи вебхук в Meta (см. ПРОЧТИ-МЕНЯ.md, шаг 3).');
