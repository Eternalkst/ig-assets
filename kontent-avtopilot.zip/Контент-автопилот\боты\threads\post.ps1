﻿# Автопостер Threads — публикует следующий пост из queue.md через официальный Threads API.
# Запуск вручную:   powershell -NoProfile -ExecutionPolicy Bypass -File post.ps1
# Посмотреть, что уйдёт следующим (без публикации):  ... post.ps1 -Preview
param(
  [switch]$Preview
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$logFile = Join-Path $dir 'log.txt'

function Log([string]$m) {
  $line = ('{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m)
  Add-Content -Path $logFile -Value $line -Encoding UTF8
  Write-Host $line
}

# ---------- очередь ----------
$queuePath = Join-Path $dir 'queue.md'
if (-not (Test-Path $queuePath)) { Log 'Нет queue.md'; exit 1 }
$raw = Get-Content $queuePath -Raw -Encoding UTF8

$blocks = [regex]::Split($raw, '(?m)^#####[ \t]+') | Where-Object { $_.Trim() -ne '' }
$queue = @()
foreach ($b in $blocks) {
  $lines = $b -split "\r?\n"
  $title = $lines[0].Trim()
  $id = ($title -split '\s+')[0]
  $body = (($lines | Select-Object -Skip 1) -join "`n").Trim()
  $parts = [regex]::Split($body, '(?m)^\+\+\+[ \t]*$') | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }
  $queue += [pscustomobject]@{ Id = $id; Title = $title; Posts = @($parts) }
}
if ($queue.Count -eq 0) { Log 'queue.md пуст'; exit 1 }

# ---------- состояние ----------
$statePath = Join-Path $dir 'state.json'
$done = @(); $skipped = @()
if (Test-Path $statePath) {
  $st = Get-Content $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($st.done)    { $done    = @($st.done) }
  if ($st.skipped) { $skipped = @($st.skipped) }
}
function Save-State {
  [pscustomobject]@{ done = $done; skipped = $skipped } |
    ConvertTo-Json | Set-Content -Path $statePath -Encoding UTF8
}

# ---------- выбор следующего поста ----------
$next = $null
foreach ($q in $queue) {
  if ($done -contains $q.Id -or $skipped -contains $q.Id) { continue }
  $joined = $q.Posts -join ' '
  $tooLong = @($q.Posts | Where-Object { $_.Length -gt 500 })
  if ($joined -match '\[') {
    if ($Preview) { Write-Host ("(будет пропущен: {0} — остались [скобки])" -f $q.Title); continue }
    Log ("ПРОПУСК {0} «{1}»: в тексте остались [скобки] — заполни текст и удали id из skipped в state.json" -f $q.Id, $q.Title)
    $skipped += $q.Id; continue
  }
  if ($tooLong.Count -gt 0) {
    if ($Preview) { Write-Host ("(будет пропущен: {0} — часть длиннее 500 символов)" -f $q.Title); continue }
    Log ("ПРОПУСК {0} «{1}»: часть поста длиннее 500 символов — сократи" -f $q.Id, $q.Title)
    $skipped += $q.Id; continue
  }
  $next = $q; break
}

if (-not $next) {
  if (-not $Preview) { Save-State }
  Log 'Очередь закончилась — добавь посты в queue.md (идеи в ../03-100-идей.md)'
  exit 0
}

if ($Preview) {
  Write-Host ''
  Write-Host ("=== Следующий к публикации: {0} (частей: {1}) ===" -f $next.Title, $next.Posts.Count)
  $i = 0
  foreach ($p in $next.Posts) {
    $i++
    Write-Host ("--- часть {0} ({1} симв.) ---" -f $i, $p.Length)
    Write-Host $p
  }
  exit 0
}

# ---------- токен ----------
$tokenPath = Join-Path $dir 'token.txt'
$metaPath  = Join-Path $dir 'token-meta.json'
$meta = $null
if (Test-Path $metaPath) { $meta = Get-Content $metaPath -Raw -Encoding UTF8 | ConvertFrom-Json }
if (Test-Path $tokenPath) {
  $t = (Get-Content $tokenPath -Raw -Encoding UTF8).Trim()
  if ($t -and ((-not $meta) -or ($meta.token -ne $t))) {
    $meta = [pscustomobject]@{ token = $t; refreshed = (Get-Date).ToString('o') }
    $meta | ConvertTo-Json | Set-Content -Path $metaPath -Encoding UTF8
  }
}
if (((-not $meta) -or (-not $meta.token)) -and $env:THREADS_TOKEN) {
  # облачный запуск (GitHub Actions): токен приходит из секрета
  $meta = [pscustomobject]@{ token = $env:THREADS_TOKEN; refreshed = (Get-Date).ToString('o') }
  $meta | ConvertTo-Json | Set-Content -Path $metaPath -Encoding UTF8
}
if ((-not $meta) -or (-not $meta.token)) {
  Log 'НЕТ ТОКЕНА: вставь долгоживущий токен Threads в файл token.txt (инструкция: README-настройка.md)'
  exit 1
}
$token = $meta.token

# продление токена (живёт 60 дней, продлеваем после 40)
$age = (Get-Date) - [datetime]$meta.refreshed
if ($age.TotalDays -gt 40) {
  try {
    $r = Invoke-RestMethod -Uri ("https://graph.threads.net/refresh_access_token?grant_type=th_refresh_token&access_token={0}" -f $token)
    $meta = [pscustomobject]@{ token = $r.access_token; refreshed = (Get-Date).ToString('o') }
    $meta | ConvertTo-Json | Set-Content -Path $metaPath -Encoding UTF8
    Set-Content -Path $tokenPath -Value $r.access_token -Encoding UTF8
    $token = $r.access_token
    Log 'Токен продлён ещё на 60 дней'
  } catch {
    Log ("Не удалось продлить токен: {0}" -f $_.Exception.Message)
  }
}

# ---------- публикация ----------
try {
  $me = Invoke-RestMethod -Uri ("https://graph.threads.net/v1.0/me?fields=id,username&access_token={0}" -f $token)
} catch {
  Log ("Токен не работает: {0}" -f $_.Exception.Message)
  exit 1
}
$uid = $me.id

function Publish-Part([string]$text, [string]$replyTo) {
  $body = "media_type=TEXT&text=$([uri]::EscapeDataString($text))&access_token=$token"
  if ($replyTo) { $body += "&reply_to_id=$replyTo" }
  $c = Invoke-RestMethod -Method Post -Uri ("https://graph.threads.net/v1.0/{0}/threads" -f $uid) `
        -Body $body -ContentType 'application/x-www-form-urlencoded'
  Start-Sleep -Seconds 8
  $p = Invoke-RestMethod -Method Post -Uri ("https://graph.threads.net/v1.0/{0}/threads_publish" -f $uid) `
        -Body ("creation_id={0}&access_token={1}" -f $c.id, $token) -ContentType 'application/x-www-form-urlencoded'
  return $p.id
}

try {
  $parentId = $null
  $i = 0
  foreach ($p in $next.Posts) {
    $i++
    $parentId = Publish-Part $p $parentId
    Log ("Опубликована часть {0}/{1} поста {2} (media id {3})" -f $i, $next.Posts.Count, $next.Id, $parentId)
    if ($i -lt $next.Posts.Count) { Start-Sleep -Seconds 15 }
  }
  $done += $next.Id
  Save-State
  Log ("ГОТОВО: «{0}» опубликован в @{1}" -f $next.Title, $me.username)
} catch {
  Save-State
  Log ("ОШИБКА публикации «{0}»: {1}" -f $next.Title, $_.Exception.Message)
  exit 1
}
