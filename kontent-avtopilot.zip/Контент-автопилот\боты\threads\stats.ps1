﻿# Аналитика Threads — собирает статистику последних постов и пишет отчёт stats-report.md
# Запуск вручную: powershell -NoProfile -ExecutionPolicy Bypass -File stats.ps1
param(
  [int]$Limit = 25
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$logFile = Join-Path $dir 'log.txt'
function Log([string]$m) {
  $line = ('{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m)
  Add-Content -Path $logFile -Value $line -Encoding UTF8
  Write-Host $line
}

# ---------- токен (общий с post.ps1) ----------
$tokenPath = Join-Path $dir 'token.txt'
$metaPath  = Join-Path $dir 'token-meta.json'
$meta = $null
if (Test-Path $metaPath) { $meta = Get-Content $metaPath -Raw -Encoding UTF8 | ConvertFrom-Json }
if ((-not $meta) -and (Test-Path $tokenPath)) {
  $t = (Get-Content $tokenPath -Raw -Encoding UTF8).Trim()
  if ($t) { $meta = [pscustomobject]@{ token = $t; refreshed = (Get-Date).ToString('o') } }
}
if (((-not $meta) -or (-not $meta.token)) -and $env:THREADS_TOKEN) {
  $meta = [pscustomobject]@{ token = $env:THREADS_TOKEN; refreshed = (Get-Date).ToString('o') }
  $meta | ConvertTo-Json | Set-Content -Path $metaPath -Encoding UTF8
}
if ((-not $meta) -or (-not $meta.token)) { Log 'СТАТИСТИКА: нет токена (token.txt)'; exit 1 }
$token = $meta.token

# ---------- данные ----------
try {
  $me = Invoke-RestMethod -Uri ("https://graph.threads.net/v1.0/me?fields=id,username&access_token={0}" -f $token)
} catch {
  Log ("СТАТИСТИКА: токен не работает: {0}" -f $_.Exception.Message); exit 1
}

$followers = $null
try {
  $fi = Invoke-RestMethod -Uri ("https://graph.threads.net/v1.0/{0}/threads_insights?metric=followers_count&access_token={1}" -f $me.id, $token)
  $followers = $fi.data[0].total_value.value
} catch { }

$list = Invoke-RestMethod -Uri ("https://graph.threads.net/v1.0/me/threads?fields=id,text,permalink,timestamp&limit={0}&access_token={1}" -f $Limit, $token)

$rows = @()
foreach ($p in $list.data) {
  $m = @{ views = 0; likes = 0; replies = 0; reposts = 0; quotes = 0 }
  try {
    $ins = Invoke-RestMethod -Uri ("https://graph.threads.net/v1.0/{0}/insights?metric=views,likes,replies,reposts,quotes&access_token={1}" -f $p.id, $token)
    foreach ($d in $ins.data) {
      $val = 0
      if ($d.values -and $d.values.Count -gt 0) { $val = $d.values[0].value }
      elseif ($d.total_value) { $val = $d.total_value.value }
      $m[$d.name] = $val
    }
  } catch {
    Log ("СТАТИСТИКА: не получил insights поста {0}: {1}" -f $p.id, $_.Exception.Message)
  }
  $txt = ''
  if ($p.text) { $txt = ($p.text -replace "\s+", ' ').Trim() }
  if ($txt.Length -gt 70) { $txt = $txt.Substring(0, 70) + '…' }
  $rows += [pscustomobject]@{
    Date    = ([datetime]$p.timestamp).ToString('dd.MM HH:mm')
    Hook    = $txt
    Views   = [int]$m.views
    Likes   = [int]$m.likes
    Replies = [int]$m.replies
    Reposts = [int]$m.reposts + [int]$m.quotes
    Link    = $p.permalink
    Id      = $p.id
  }
  Start-Sleep -Milliseconds 500
}

if ($rows.Count -eq 0) { Log 'СТАТИСТИКА: постов не найдено'; exit 0 }

# ---------- анализ ----------
$sorted = $rows | Sort-Object Views -Descending
$viewsArr = @($rows | ForEach-Object { $_.Views } | Sort-Object)
$median = $viewsArr[[int][math]::Floor($viewsArr.Count / 2)]
if ($median -lt 1) { $median = 1 }
$totalViews = ($rows | Measure-Object Views -Sum).Sum
$totalReplies = ($rows | Measure-Object Replies -Sum).Sum

# ---------- отчёт ----------
$report = @()
$report += ('# Отчёт Threads @{0} — {1}' -f $me.username, (Get-Date -Format 'dd.MM.yyyy HH:mm'))
$report += ''
if ($null -ne $followers) { $report += ('Подписчиков: **{0}**' -f $followers) }
$report += ('Постов в отчёте: {0} | Суммарно просмотров: {1} | Комментариев: {2} | Медиана просмотров: {3}' -f $rows.Count, $totalViews, $totalReplies, $median)
$report += ''
$report += '## Посты по просмотрам'
$report += ''
$report += '| Дата | Пост | 👁 | ❤ | 💬 | 🔁 | vs медиана |'
$report += '|------|------|----|----|----|----|------------|'
foreach ($r in $sorted) {
  $ratio = [math]::Round($r.Views / $median, 1)
  $mark = ''
  if ($ratio -ge 2)      { $mark = ('**x{0} — МАСШТАБИРУЙ ФОРМАТ**' -f $ratio) }
  elseif ($ratio -ge 1)  { $mark = ('x{0}' -f $ratio) }
  else                   { $mark = ('x{0} (слабее обычного)' -f $ratio) }
  $report += ('| {0} | [{1}]({2}) | {3} | {4} | {5} | {6} | {7} |' -f $r.Date, $r.Hook, $r.Link, $r.Views, $r.Likes, $r.Replies, $r.Reposts, $mark)
}
$report += ''
$report += '## Как читать'
$report += '- **x2 и выше** — формат зашёл: делай похожие 2–3 раза в неделю.'
$report += '- Много 💬 при средних 👁 — тема цепляет, усили хук первой строки и повтори.'
$report += '- Много 👁 при нуле 💬 — охват есть, вовлечения нет: добавь вопрос или спорный тезис в конец.'
$report += '- Слабее x0.5 три раза подряд у одного формата — убирай формат из ротации.'

$reportPath = Join-Path $dir 'stats-report.md'
$report -join "`r`n" | Set-Content -Path $reportPath -Encoding UTF8

# ---------- история (для динамики) ----------
$histPath = Join-Path $dir 'stats-history.csv'
if (-not (Test-Path $histPath)) {
  'runDate;followers;postId;postDate;views;likes;replies;reposts' | Set-Content -Path $histPath -Encoding UTF8
}
$runDate = Get-Date -Format 'yyyy-MM-dd HH:mm'
foreach ($r in $rows) {
  ('{0};{1};{2};{3};{4};{5};{6};{7}' -f $runDate, $followers, $r.Id, $r.Date, $r.Views, $r.Likes, $r.Replies, $r.Reposts) |
    Add-Content -Path $histPath -Encoding UTF8
}

Log ('СТАТИСТИКА: отчёт готов — stats-report.md ({0} постов, медиана {1} просмотров)' -f $rows.Count, $median)
