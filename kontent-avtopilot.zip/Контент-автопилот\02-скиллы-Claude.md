# 🧩 Скиллы Claude, которые нужны для сборки автопилота

«Скилл» — это набор инструкций, который делает Claude экспертом в конкретной задаче (копирайтинг, дизайн, создание PDF и т.д.). Перед тем как собирать контент-автопилот, поставь эти скиллы — с ними Claude сделает всё в разы качественнее.

## Как установить скиллы (2 способа)

**Способ 1 — через маркетплейс плагинов (проще):**
1. Открой Claude Code.
2. Введи команду `/plugin` — откроется каталог.
3. Найди нужные наборы (Marketing, Design, anthropic-skills) и нажми Install.

**Способ 2 — вручную (папкой):**
1. Скачай скилл (папку со `SKILL.md` внутри).
2. Положи её в `C:\Users\ТЫ\.claude\skills\` (на Mac: `~/.claude/skills/`).
3. Перезапусти Claude Code — скилл появится.

Проверить установленные: команда `/help` или спроси Claude «какие у тебя скиллы».

## Рекомендованный набор под этот продукт

### Обязательные (контент и запуск)
- **copywriting** — тексты постов, которые продают
- **offers** — упаковка оффера и цены
- **lead-magnets** — бесплатный материал-приманка
- **marketing-plan** — стратегия контента
- **content-strategy** — план публикаций
- **ads** — если будешь докручивать таргет

### Для дизайна (карусели, сайт, баннеры)
- **ui-ux-pro-max** — дизайн интерфейсов и лендингов
- **banner-design** — баннеры и креативы
- **design** / **design-system** — фирменный стиль, слайды
- **ui-styling** — красивые компоненты, тёмная тема, анимации

### Для документов
- **pdf** — сборка PDF-инструкций
- **docx** — документы Word
- **canvas-design** — обложки и визуал

### Полезные
- **deep-research** — исследование конкурентов и ниши
- **skill-creator** — если захочешь сделать свой скилл
- **dataviz** — графики и отчёты

## Полный список того, что было использовано при сборке этого продукта
Marketing-набор (ab-testing, ad-creative, ads, ai-seo, analytics, copywriting, cro, customer-research, lead-magnets, marketing-plan, offers, pricing, sales-enablement и др.), Design-набор (banner-design, brand, design, design-system, slides, ui-styling, ui-ux-pro-max), anthropic-skills (canvas-design, docx, pdf, pptx, xlsx, skill-creator, stop-slop, brand-guidelines), а также dataviz, deep-research, artifact-design.

> Не обязательно ставить всё. Для старта хватит блока «Обязательные» + «Для документов». Остальное — по мере роста.
