﻿# Создаёт два задания в Планировщике Windows: публикация ежедневно в 09:30 и 20:30.
# Запуск: powershell -NoProfile -ExecutionPolicy Bypass -File register-tasks.ps1
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script = Join-Path $dir 'post.ps1'
$arg = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$script`""
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arg
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

foreach ($t in @(
  @{ Name = 'Threads-Autopost-Utro';   At = '09:30' },
  @{ Name = 'Threads-Autopost-Den';    At = '14:00' },
  @{ Name = 'Threads-Autopost-Vecher'; At = '20:30' }
)) {
  $trigger = New-ScheduledTaskTrigger -Daily -At $t.At
  Register-ScheduledTask -TaskName $t.Name -Action $action -Trigger $trigger -Settings $settings -Force | Out-Null
  Write-Host ("Задание {0}: ежедневно в {1}" -f $t.Name, $t.At)
}

# Еженедельная аналитика: воскресенье 21:30 → stats-report.md
$statsScript = Join-Path $dir 'stats.ps1'
$statsArg = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$statsScript`""
$statsAction = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $statsArg
$statsTrigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At '21:30'
Register-ScheduledTask -TaskName 'Threads-Stats-Weekly' -Action $statsAction -Trigger $statsTrigger -Settings $settings -Force | Out-Null
Write-Host 'Задание Threads-Stats-Weekly: каждое воскресенье в 21:30 (отчёт stats-report.md)'
Write-Host 'Готово. Компьютер должен быть включён в это время (если был выключен — пост уйдёт при включении).'
