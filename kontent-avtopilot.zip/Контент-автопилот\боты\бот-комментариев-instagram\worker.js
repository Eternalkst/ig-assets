// Instagram comment/DM bot — Cloudflare Worker (с отладочным журналом в KV).
const GRAPH = 'https://graph.instagram.com/v23.0';

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    // отладка: /debug — показать последние события
    if (url.pathname === '/debug') {
      const list = await env.DEBUG.list({ limit: 50 });
      const items = [];
      for (const k of list.keys) {
        items.push({ key: k.name, value: JSON.parse((await env.DEBUG.get(k.name)) || 'null') });
      }
      items.sort((a, b) => (a.key < b.key ? 1 : -1));
      return new Response(JSON.stringify(items, null, 2), { headers: { 'Content-Type': 'application/json' } });
    }

    if (request.method === 'GET') {
      const mode = url.searchParams.get('hub.mode');
      const token = url.searchParams.get('hub.verify_token');
      const challenge = url.searchParams.get('hub.challenge');
      if (mode === 'subscribe' && token === env.VERIFY_TOKEN) {
        return new Response(challenge, { status: 200 });
      }
      return new Response('forbidden', { status: 403 });
    }

    if (request.method === 'POST') {
      let raw = '';
      try { raw = await request.text(); } catch {}
      let body = null;
      try { body = JSON.parse(raw); } catch {}
      await dbg(env, 'IN', { raw });
      if (body) ctx.waitUntil(handle(body, env));
      return new Response('EVENT_RECEIVED', { status: 200 });
    }

    return new Response('ig-bot ok', { status: 200 });
  }
};

async function dbg(env, tag, data) {
  try {
    const key = `${Date.now()}-${tag}-${Math.floor(Math.random() * 1000)}`;
    await env.DEBUG.put(key, JSON.stringify({ tag, ...data }), { expirationTtl: 86400 });
  } catch {}
}

function rules(env) {
  try { return JSON.parse(env.KEYWORDS_JSON || '[]'); } catch { return []; }
}
function matchRule(text, env) {
  const t = (text || '').toLowerCase().trim();
  for (const r of rules(env)) for (const m of (r.match || [])) if (t.includes(String(m).toLowerCase())) return r;
  return null;
}

async function handle(body, env) {
  if (body.object !== 'instagram') { await dbg(env, 'SKIP', { reason: 'object', object: body.object }); return; }
  const selfId = env.IG_USER_ID;

  for (const entry of (body.entry || [])) {
    for (const ch of (entry.changes || [])) {
      if (ch.field !== 'comments') { await dbg(env, 'SKIP', { field: ch.field }); continue; }
      const v = ch.value || {};
      const fromId = v.from && v.from.id;
      await dbg(env, 'COMMENT', { text: v.text, fromId, selfId, commentId: v.id });
      if (fromId && fromId === selfId) { await dbg(env, 'SKIP', { reason: 'self-comment' }); continue; }
      const rule = matchRule(v.text, env);
      if (!rule) { await dbg(env, 'NOMATCH', { text: v.text }); continue; }
      if (rule.comment_reply) await igPost(`${GRAPH}/${v.id}/replies`, { message: rule.comment_reply }, env);
      await sendDM({ comment_id: v.id }, rule, env);
    }

    for (const m of (entry.messaging || [])) {
      const senderId = m.sender && m.sender.id;
      await dbg(env, 'MSG', { senderId, text: m.message && m.message.text, echo: m.message && m.message.is_echo });
      if (!senderId || senderId === selfId) continue;
      if (m.message && m.message.is_echo) continue;
      const rule = matchRule(m.message && m.message.text, env);
      if (!rule) continue;
      await sendDM({ id: senderId }, rule, env);
    }
  }
}

async function sendDM(recipient, rule, env) {
  let message;
  if (rule.button_url && rule.button_title) {
    message = { attachment: { type: 'template', payload: { template_type: 'button', text: rule.dm_text || 'Держи 👇', buttons: [{ type: 'web_url', url: rule.button_url, title: rule.button_title }] } } };
  } else {
    message = { text: rule.dm_text || 'Держи 👇' };
  }
  await igPost(`${GRAPH}/${env.IG_USER_ID}/messages`, { recipient, message }, env);
}

async function igPost(urlBase, payload, env) {
  const url = `${urlBase}?access_token=${encodeURIComponent(env.IG_TOKEN)}`;
  try {
    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const t = await res.text();
    await dbg(env, 'APICALL', { url: urlBase, status: res.status, resp: t.slice(0, 500), sent: JSON.stringify(payload).slice(0, 300) });
  } catch (e) {
    await dbg(env, 'APIERR', { url: urlBase, err: e.message });
  }
}
