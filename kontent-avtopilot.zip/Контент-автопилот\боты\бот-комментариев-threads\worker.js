// Threads-бот: мгновенная реакция на комментарии через вебхук (поле "replies").
// ГИБРИД: ключевое слово → ссылка на промпт; осмысленный вопрос → ответ Claude в стиле Валерия.
const API = 'https://graph.threads.net/v1.0';
const ANTHROPIC = 'https://api.anthropic.com/v1/messages';

// два маршрута лид-магнита:
// AUTO — человек хочет саму автоматизацию → ведём на страницу продукта
const AUTO_KW = ['автомат', 'автоматизация', 'автопилот', 'автопостинг', 'система', 'подключ', 'ключ'];
// PROMPT — человек хочет забрать пользу (промпт) → ведём на промпт (там апселл на автоматизацию)
const PROMPT_KW = ['хочу', 'промпт', 'гайд', 'бот', 'дай', 'шаблон', 'посты', 'пост', '🔥'];
// слова-подтверждения подписки (шаг 2 мягкого гейта)
const DONE_KW = ['готово', 'готов', 'подписался', 'подписалась', 'подписка', 'подпис', 'done', 'сделал', 'сделано', 'го'];

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname === '/debug') {
      const list = await env.KV.list({ prefix: 'dbg:', limit: 50 });
      const items = [];
      for (const k of list.keys) items.push(JSON.parse((await env.KV.get(k.name)) || 'null'));
      items.sort((a, b) => (a && b ? (a.t < b.t ? 1 : -1) : 0));
      return new Response(JSON.stringify(items, null, 2), { headers: { 'Content-Type': 'application/json' } });
    }

    if (request.method === 'GET') {
      const mode = url.searchParams.get('hub.mode');
      const token = url.searchParams.get('hub.verify_token');
      const challenge = url.searchParams.get('hub.challenge');
      if (mode === 'subscribe' && token === env.VERIFY_TOKEN) return new Response(challenge, { status: 200 });
      return new Response('forbidden', { status: 403 });
    }

    if (request.method === 'POST') {
      let raw = ''; try { raw = await request.text(); } catch {}
      let body = null; try { body = JSON.parse(raw); } catch {}
      await dbg(env, 'IN', { raw: raw.slice(0, 800) });
      if (body) ctx.waitUntil(handle(body, env));
      return new Response('EVENT_RECEIVED', { status: 200 });
    }
    return new Response('threads-bot ok');
  }
};

async function dbg(env, tag, data) {
  try { await env.KV.put(`dbg:${Date.now()}-${Math.floor(Math.random() * 1000)}`, JSON.stringify({ t: Date.now(), tag, ...data }), { expirationTtl: 86400 }); } catch {}
}

// Threads присылает { values: {field, value} } (иногда массивом);
// на всякий случай поддерживаем и старый формат entry[].changes[].
function extractReplies(body) {
  const out = [];
  const push = (field, value) => { if (field === 'replies' && value && value.id) out.push(value); };
  if (body.values) {
    const arr = Array.isArray(body.values) ? body.values : [body.values];
    for (const v of arr) push(v.field, v.value);
  }
  for (const entry of (body.entry || [])) {
    for (const ch of (entry.changes || [])) push(ch.field, ch.value);
  }
  return out;
}

// поднимаемся вверх по ветке ответов, собираем контекст (пост + предыдущие реплики)
async function fetchMedia(id, env) {
  try {
    const u = new URL(`${API}/${id}`);
    u.searchParams.set('fields', 'id,text,username,replied_to');
    u.searchParams.set('access_token', env.THREADS_TOKEN);
    return await (await fetch(u)).json();
  } catch { return null; }
}
async function buildContext(v, env) {
  const selfName = (env.THREADS_USERNAME || '').toLowerCase();
  const chain = [];
  let pid = v.replied_to && v.replied_to.id ? String(v.replied_to.id) : '';
  let hops = 0;
  while (pid && hops < 6) {
    const m = await fetchMedia(pid, env);
    if (!m || !m.id) break;
    const mine = (m.username || '').toLowerCase() === selfName;
    chain.unshift({ mine, who: mine ? 'Я' : `@${m.username || 'клиент'}`, text: m.text || '' });
    pid = m.replied_to && m.replied_to.id ? String(m.replied_to.id) : '';
    hops++;
  }
  return chain; // от старого (пост) к новому (родитель текущего коммента)
}

async function handle(body, env) {
  const selfName = (env.THREADS_USERNAME || '').toLowerCase();

  for (const v of extractReplies(body)) {
    const rid = String(v.id);

    // дедуп — вебхук может прийти дважды
    if (await env.KV.get(`seen:${rid}`)) continue;
    await env.KV.put(`seen:${rid}`, '1', { expirationTtl: 604800 });

    // не отвечаем сами себе (у Threads автор — только по username)
    const uname = (v.username || '').toLowerCase();
    if (selfName && uname === selfName) continue;

    const text = v.text || '';
    const words = text.toLowerCase().split(/[^\p{L}\p{N}🔥]+/u).filter(Boolean);

    // контекст ветки — чтобы держать разговор, а не отвечать вслепую
    const chain = await buildContext(v, env);
    const ongoing = chain.slice(1).some(c => c.mine); // я уже отвечал в этой ветке → это диалог
    await dbg(env, 'REPLY', { rid, uname, ongoing, ctx: chain.length, text: text.slice(0, 160) });

    // ШАГ 2 гейта: человек подтвердил подписку («готово») → кидаем ссылку.
    // Надёжность: сначала KV-метка, а если её ещё нет — определяем по контексту
    // (родитель — гейт-сообщение бота со словом «ГОТОВО»), маршрут берём из исходного коммента ветки.
    let pending = await env.KV.get(`gate:${uname}`);
    if (!pending && chain.length && chain[chain.length - 1].mine && /ГОТОВО/i.test(chain[chain.length - 1].text)) {
      const uw = chain.filter(c => !c.mine).map(c => c.text.toLowerCase()).join(' ')
        .split(/[^\p{L}\p{N}🔥]+/u).filter(Boolean);
      pending = AUTO_KW.some(k => uw.includes(k)) ? 'auto' : 'prompt';
    }
    if (pending && DONE_KW.some(k => words.includes(k))) {
      await env.KV.delete(`gate:${uname}`);
      if (pending === 'auto') {
        await postReply(rid, `Супер, спасибо за подписку 🙌 Держи — вот как поставить контент и ответы клиентам на автопилот (посты, директ, WhatsApp сами) 👉 ${env.AVTOPILOT_URL}`, env);
      } else {
        await postReply(rid, `Супер, спасибо за подписку 🙌 Лови промпт — соберёт тебе 40 постов под нишу 👉 ${env.PROMPT_URL}`, env);
      }
      continue;
    }

    // ШАГ 1 гейта: первый коммент с ключевым словом → просим подписаться и написать ГОТОВО
    if (!ongoing) {
      const route = AUTO_KW.some(k => words.includes(k)) ? 'auto'
                  : PROMPT_KW.some(k => words.includes(k)) ? 'prompt' : null;
      if (route) {
        await env.KV.put(`gate:${uname}`, route, { expirationTtl: 172800 });
        await postReply(rid, `Отлично, сейчас скину 🙌 Только подпишись на меня, чтоб не потерять — и напиши в ответ ГОТОВО, сразу отправлю 👇`, env);
        continue;
      }
    }

    // всё остальное → полноценный ИИ-ответчик с контекстом.
    // Работает только в режиме FULL. Если BOT_MODE='keywords' — бот реагирует
    // ТОЛЬКО на ключевые слова (лид-магнит + гейт), а на обычные комменты молчит.
    if ((env.BOT_MODE || 'full').toLowerCase() === 'keywords') continue;
    const ai = await askClaude(chain, uname, text, env);
    if (ai && ai.trim() && ai.trim().toUpperCase() !== 'SKIP') {
      await postReply(rid, ai.trim().slice(0, 480), env);
    }
  }
}

async function askClaude(chain, uname, text, env) {
  if (!env.ANTHROPIC_API_KEY) return 'SKIP';

  const transcript = [...chain.map(c => `${c.who}: ${c.text}`), `@${uname}: ${text}`].join('\n');

  const system = `Ты — личный продажник-ассистент владельца этого аккаунта в комментариях Threads. Отвечаешь от его лица.

О ВЛАДЕЛЬЦЕ И ЕГО ПРОДУКТЕ (используй это, чтобы продавать по делу):
${env.BOT_PERSONA || 'Владелец продаёт свой продукт или услугу и хочет превращать комментарии под постами в заявки.'}

ТВОЯ ЦЕЛЬ — превращать интерес в заявку. Ты ведёшь диалог как живой уверенный продажник, а не нейтральный консультант.

ЖЁСТКИЕ ПРАВИЛА:
— НИКОГДА не отговаривай от продукта и не приуменьшай его. Запрещено писать «можно и без этого», «вас и так найдут», «это не всем нужно». Наоборот — показывай, зачем это нужно и что решает.
— Продавай выгодой уверенно, опираясь на описание продукта выше. Говори конкретно, что человек получит и какую его боль это закрывает.
— ВСЕГДА давай конкретный следующий шаг, чтобы человек не гадал куда писать: либо ссылку ${env.AVTOPILOT_URL}, либо «напиши АВТОМАТ — пришлю детали». Без этого ответ неполный.
— Держи разговор: тебе дают всю ветку. Отвечай по смыслу на ПОСЛЕДНЮЮ реплику, продолжая диалог. Если человек проявил интерес («давай», «расскажи», «сколько», «как») — двигай к сделке: 1 фраза выгоды + следующий шаг/ссылка.
— НЕ будь навязчивым к явно незаинтересованным: если человек прямо говорит «не надо / не интересно / у меня своё» — не дави, ответь по-доброму одной фразой и оставь дверь открытой («будет актуально — я рядом»). Но НЕ отговаривай от продукта.
— Если ты уже ответил 2–3 раза, а человек не двигается к делу — заверши мягко, без спама.
— Оскорбления, троллинг, спам, чужая реклама, мусор, голые эмодзи без смысла → верни РОВНО одно слово: SKIP
— ПОЛ человека неизвестен (есть только ник). Обращайся гендерно-нейтрально: НЕ пиши «красавчик/красава/дорогой/бро/подписался/готов» и другие формы с родом. Используй нейтральные обороты («привет», «спасибо за подписку», «если интересно»). Не приписывай собеседнику род.
— Не выдумывай цифры, кейсы, гарантии. Пиши коротко (1–3 предложения, до 400 символов), по-свойски, без канцелярита и хэштегов, на языке человека.

Верни ТОЛЬКО текст ответа для публикации, либо слово SKIP. Без кавычек и пояснений.`;

  try {
    const r = await fetch(ANTHROPIC, {
      method: 'POST',
      headers: {
        'x-api-key': env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 300,
        system,
        messages: [{ role: 'user', content: `Ветка под моим постом в Threads (сверху вниз — от старого к новому). Ответь ТОЛЬКО на последнюю реплику (@${uname}), продолжая разговор как продажник:\n\n${transcript}` }],
      }),
    });
    const j = await r.json();
    const txt = j && j.content && j.content[0] && j.content[0].text ? j.content[0].text : 'SKIP';
    await dbg(env, 'AI', { status: r.status, out: String(txt).slice(0, 200) });
    return txt;
  } catch (e) {
    await dbg(env, 'AIERR', { err: e.message });
    return 'SKIP';
  }
}

async function postReply(replyToId, text, env) {
  const uid = String(env.THREADS_USER_ID);
  try {
    const c = new URL(`${API}/${uid}/threads`);
    c.searchParams.set('access_token', env.THREADS_TOKEN);
    const cb = new URLSearchParams({ media_type: 'TEXT', text, reply_to_id: replyToId });
    const cr = await (await fetch(c, { method: 'POST', body: cb })).json();
    if (!cr.id) { await dbg(env, 'POSTERR', { stage: 'create', resp: JSON.stringify(cr).slice(0, 300) }); return; }

    const p = new URL(`${API}/${uid}/threads_publish`);
    p.searchParams.set('access_token', env.THREADS_TOKEN);
    const pb = new URLSearchParams({ creation_id: cr.id });
    const pr = await (await fetch(p, { method: 'POST', body: pb })).json();
    await dbg(env, 'POSTED', { replyToId, resp: JSON.stringify(pr).slice(0, 200) });
  } catch (e) {
    await dbg(env, 'POSTEX', { err: e.message });
  }
}
