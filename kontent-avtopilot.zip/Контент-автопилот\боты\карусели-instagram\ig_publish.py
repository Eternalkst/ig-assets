# Публикует следующую карусель из ig_queue.json в Instagram. Чистый UTF-8 (без bash!).
# Токен и id берутся из переменных окружения (в облаке — из секретов GitHub).
import os, json, time, urllib.request, urllib.parse

BASE = os.path.dirname(os.path.abspath(__file__))
GRAPH = "https://graph.instagram.com/v23.0"
IG_ID = os.environ.get("IG_USER_ID", "ТВОЙ_IG_USER_ID")
TOKEN = os.environ.get("IG_TOKEN") or open(os.path.join(BASE, "token.txt"), encoding="utf-8").read().strip()

def api_post(path, params):
    data = urllib.parse.urlencode(params, encoding="utf-8").encode("utf-8")
    req = urllib.request.Request(f"{GRAPH}/{path}", data=data, method="POST")
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read().decode("utf-8"))

def publish_carousel(caption, image_urls):
    children = []
    for url in image_urls:
        r = api_post(f"{IG_ID}/media", {"image_url": url, "is_carousel_item": "true", "access_token": TOKEN})
        if "id" not in r: raise RuntimeError(f"кадр не принят: {r}")
        children.append(r["id"])
    r = api_post(f"{IG_ID}/media", {"media_type": "CAROUSEL", "children": ",".join(children),
                                    "caption": caption, "access_token": TOKEN})
    if "id" not in r: raise RuntimeError(f"карусель не собралась: {r}")
    time.sleep(5)
    return api_post(f"{IG_ID}/media_publish", {"creation_id": r["id"], "access_token": TOKEN})

def next_from_queue():
    queue = json.load(open(os.path.join(BASE, "ig_queue.json"), encoding="utf-8"))
    spath = os.path.join(BASE, "ig_state.json")
    state = json.load(open(spath, encoding="utf-8")) if os.path.exists(spath) else {"done": []}
    for item in queue:
        if item["id"] in state["done"]: continue
        print("Публикую:", item["id"])
        pub = publish_carousel(item["caption"], item["images"])
        print("Опубликовано:", pub)
        state["done"].append(item["id"])
        json.dump(state, open(spath, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        return pub
    print("Очередь пуста — сгенерируй новые карусели (make_carousels.py)")
    return None

if __name__ == "__main__":
    next_from_queue()
